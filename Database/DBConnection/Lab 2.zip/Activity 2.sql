CREATE DATABASE myPractical;
USE myPractical;
CREATE TABLE Customer(
custID INT(4),
custName VARCHAR(50),
custJob VARCHAR(30),
custAddr1 VARCHAR(100),
custAddr2 VARCHAR (100),
custState VARCHAR (30),
custPostCode VARCHAR (10),
custContact VARCHAR (15)
);

CREATE TABLE Sales(
slsID INT(4),
custID INT(4),
slsType VARCHAR(10),
slsOrderDate DATE,
slsShipDate DATE
);

CREATE TABLE Product(
prdID VARCHAR (15),
prdName VARCHAR (50),
prdCategory VARCHAR(30),
prdUnit VARCHAR(15),
prdCostPrice DECIMAL(8,2),
prdSalesPrice DECIMAL (8,2)
);

DESCRIBE Customer;
DESCRIBE Sales;
DESCRIBE Product;

SHOW COLUMNS FROM Customer;
SHOW COLUMNS FROM Sales;
SHOW COLUMNS FROM Product;

SHOW TABLES;